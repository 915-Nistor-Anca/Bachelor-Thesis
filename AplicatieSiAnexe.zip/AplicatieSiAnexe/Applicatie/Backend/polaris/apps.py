from django.apps import AppConfig


class PolarisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'polaris'
